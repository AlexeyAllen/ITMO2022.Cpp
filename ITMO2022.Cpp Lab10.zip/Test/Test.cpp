#include <iostream>

using namespace std;

class Sensor {
    int value;
public:
    Sensor() { value = 0; }
    void setValue(int value) { this->value += value; }
    int getValue() { return value; }
};

class MeasureCount
{
    int number;
    static int total;
public:
    MeasureCount() { number = 0; }
    void increment() { number++; total++; }
    int getNumber() { return number; }
    static int getTotal() { return total; }
};

int MeasureCount::total = 0;

class ITemperatureMeasure
{
public:
    virtual void setValue() = 0;
    virtual double getValue() = 0;
};

class TemperatureMeasure : public virtual ITemperatureMeasure
{
private:
    Sensor* h;        // ���������
    MeasureCount* measure;  // ����������
public:
    TemperatureMeasure(Sensor* h);
    int getNumber() { return measure->getNumber(); }
    double getValue() { return (double)h->getValue() / measure->getNumber(); }
    void setValue()
    {
        int value;
        measure->increment();
        cout << "t[" << measure->getNumber() << "]= ";
        cin >> value;
        h->setValue(value);
    }
    static int getTotal() { return MeasureCount::getTotal(); }
};

TemperatureMeasure::TemperatureMeasure(Sensor* h)
{
    measure = new MeasureCount();
    this->h = h;
}

class ShowTemperature // �����������
{
public:
    static void Show(TemperatureMeasure t)
    {
        cout << t.getNumber() << ": ";
        cout << t.getValue() << " oC" << endl;
    }
};

int main()
{
    Sensor* h1 = new Sensor();
    TemperatureMeasure tc1(h1);
    for (int i = 0; i < 5; i++)
        tc1.setValue();
    ShowTemperature::Show(tc1);
    cout << endl;
    Sensor* h2 = new Sensor();
    TemperatureMeasure tc2(h2);
    for (int i = 0; i < 5; i++)
        tc2.setValue();
    ShowTemperature::Show(tc2);
    cout << endl;
    cout << "Total: " << TemperatureMeasure::getTotal() << endl;
    cin.get(); 
    cin.get();
    return 0;
}