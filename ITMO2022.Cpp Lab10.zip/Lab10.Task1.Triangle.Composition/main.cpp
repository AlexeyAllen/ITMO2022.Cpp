#include "dot.h"
#include "triangle.h"

int main() {

	Triangle tr;

	tr.sideL();
	tr.perimTr();
	tr.areaTr();
}